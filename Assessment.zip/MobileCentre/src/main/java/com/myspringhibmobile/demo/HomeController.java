package com.myspringhibmobile.demo;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

//import com.test.dao.MobileDao;
//import com.test.model.Mobile;


@Controller
public class HomeController {
	
	@Autowired
	MobileDao mobileDao;

	@RequestMapping(value = "/")
	public String mobileDesign(Model model) {
		return "home";
	}
	ArrayList<Mobile> mobiles=new ArrayList<Mobile>();
	@RequestMapping(value = "/add")
	public String home(Model model, @ModelAttribute Mobile mobile) {
		mobileDao.saveMobile(mobile);
		return "home";
	}
	@RequestMapping(value = "/display")
	public String home(Model model) {
		//Mobile mobile=new Mobile();
		ArrayList<Mobile> mob=mobileDao.getMobiles();
		model.addAttribute("mobiles", mob);
		return "display";
		
	}
	@RequestMapping(value = "/delete")
	public String deleteMobile(Model model,@RequestParam("mobname") String mobname) {
		//Session session = factory.openSession();
		//Transaction tx = session.beginTransaction();
		mobileDao.deletebyName(mobname);
		return "home";

	}
	@RequestMapping(value = "/del")
	public String mobileDesign1(Model model) {
		return "delete";
	}
	@RequestMapping(value = "/update")
	public String mobileDesign13(Model model) {
		return "update";
	}
	@RequestMapping(value = "/updateM")
	public String mobileDesign12(@RequestParam("mobname") String mobname,@RequestParam("cost") int cost) {
		mobileDao.updateCost(mobname, cost);
		return"successfully Updated";
	}
	@RequestMapping(value = "/home")
	public String mobileDesign11(Model model) {
		return "home";
	}
}
