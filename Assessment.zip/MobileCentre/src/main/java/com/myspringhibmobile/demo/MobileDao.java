package com.myspringhibmobile.demo;

import java.util.ArrayList;


import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;



@Component
public class MobileDao {
	
	@Autowired
	SessionFactory sessionFactory;
	
	@Transactional
	public void saveMobile(Mobile mobile) {
		
		Session session=sessionFactory.getCurrentSession();
		session.save(mobile);
		}
	
	@Transactional
	public ArrayList<Mobile> getMobiles(){
		Session session=sessionFactory.getCurrentSession();
		ArrayList<Mobile> mobiles=(ArrayList<Mobile>)session.createQuery("from Mobile").list();
		return mobiles;
	}
	@Transactional
	public void deletebyName(String mobname)
	{
		Session session=sessionFactory.getCurrentSession();
		Mobile mobile=(Mobile)session.get(Mobile.class,mobname);
		session.delete(mobile);
	}
	public void updateCost(String mobname,int cost) {
		Session session=sessionFactory.getCurrentSession();
		Mobile mobile = (Mobile)session.get(Mobile.class,mobname);
		mobile.setCost(cost);
		session.update(mobile);

	}
}
