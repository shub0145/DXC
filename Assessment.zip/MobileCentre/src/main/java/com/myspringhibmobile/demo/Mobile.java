package com.myspringhibmobile.demo;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Mobile {

	
	@Id
	String mobname;
	 String brandname;
		int cost;
		public String getMobname() {
			return mobname;
		}
		public void setMobname(String mobname) {
			this.mobname = mobname;
		}
		public String getBrandname() {
			return brandname;
		}
		public void setBrandname(String brandname) {
			this.brandname = brandname;
		}
		public int getCost() {
			return cost;
		}
		public void setCost(int cost) {
			this.cost = cost;
		}

}
